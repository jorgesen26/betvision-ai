
import stringSimilarity from 'string-similarity';

export function normalizeTeamName(name?: string) {
  if (!name) return '';
  return name
    .normalize('NFD').replace(/\p{Diacritic}/gu, '')
    .replace(/(fc|sc|cf|ac|afc|u\d+)/gi, '')
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

export function pickBestMatch(target: string, candidates: string[], threshold = 0.7) {
  if (!target || !candidates.length) return null;
  const res = stringSimilarity.findBestMatch(target, candidates);
  if (res.bestMatch.rating >= threshold) return res.bestMatch.target;
  return null;
}
