
import { Router } from 'express';
import { withCache } from '../utils/cache.js';
import { getOdds } from '../services/odds.js';
const router = Router();
const cachedOdds = withCache('odds_h2h', getOdds);

router.get('/', async (_req, res) => {
  try { const data = await cachedOdds(); res.json({ data }); }
  catch (e:any) { res.status(500).json({ error: e.message }); }
});
export default router;
