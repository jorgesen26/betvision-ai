
import fetch from 'node-fetch';
import { env } from '../env.js';

export async function getOdds() {
  if (env.MOCK_MODE === '1') {
    return [
      { home_team:'Real Madrid', away_team:'Barcelona', bookmakers:[{ title:'Book A', key:'book_a', markets:[{ key:'h2h', outcomes:[
        { name:'Real Madrid', price:2.15 }, { name:'Draw', price:3.5 }, { name:'Barcelona', price:3.0 }
      ] }]}] },
      { home_team:'Arsenal', away_team:'Chelsea', bookmakers:[{ title:'Book B', key:'book_b', markets:[{ key:'h2h', outcomes:[
        { name:'Arsenal', price:2.2 }, { name:'Draw', price:3.4 }, { name:'Chelsea', price:3.1 }
      ] }]}] }
    ];
  }
  const url = `https://api.the-odds-api.com/v4/sports/soccer/odds?apiKey=${env.ODDS_API_KEY}&regions=eu,uk,us&markets=h2h`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`TheOddsAPI error: ${res.status}`);
  return res.json();
}
