
import admin from 'firebase-admin';

if (!admin.apps.length) {
  try {
    admin.initializeApp();
  } catch {}
}

export const firestore = admin.firestore();
export const authAdmin = admin.auth();
