
export type MatchFeatures = {
  homeForm: number;
  awayForm: number;
  homeAdvantage: number;
  oddsAvgHome?: number;
  oddsAvgDraw?: number;
  oddsAvgAway?: number;
};

function sigmoid(x: number) { return 1/(1+Math.exp(-x)); }

export function estimateProbabilities(f: MatchFeatures) {
  const wHome = 1.2, wAway = -1.1, wHA = 0.8, wOddsHome = -0.3, wOddsAway = 0.3;
  const xHome = wHome*f.homeForm + wHA*f.homeAdvantage + (f.oddsAvgHome? wOddsHome*f.oddsAvgHome:0);
  const xAway = wAway*f.awayForm + (f.oddsAvgAway? wOddsAway*f.oddsAvgAway:0);
  const xDraw = 0.2*(f.homeForm + f.awayForm) - 0.1*Math.abs(f.homeForm - f.awayForm);
  let pHome = sigmoid(xHome + 0.1), pAway = sigmoid(xAway), pDraw = sigmoid(xDraw - 0.2);
  const s = pHome + pDraw + pAway; pHome/=s; pDraw/=s; pAway/=s; return { pHome, pDraw, pAway };
}
