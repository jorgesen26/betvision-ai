
import { auth } from '../firebase';
const BASE = import.meta.env.VITE_SERVER_BASE_URL || '';
export async function authedFetch(url: string, init?: RequestInit){
  const token = await auth.currentUser?.getIdToken?.();
  const headers = new Headers(init?.headers || {});
  if (token) headers.set('Authorization', `Bearer ${token}`);
  return fetch(`${BASE}${url}`, { ...init, headers });
}
export const swrAuthedFetcher = (url: string) => authedFetch(url).then(async r=>{ if(!r.ok){ const err:any=new Error('Request failed'); err.status=r.status; try{ err.info=await r.json(); }catch{} throw err; } return r.json(); });
