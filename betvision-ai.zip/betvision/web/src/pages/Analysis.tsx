
import { useParams, Link } from 'react-router-dom';
import useSWR from 'swr';
import { swrAuthedFetcher } from '../lib/fetcher';
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import LegalFooter from '../components/LegalFooter';

export default function Analysis(){
  const params = useParams();
  const home = params.home!; const away = params.away!;
  const { data, error, isLoading } = useSWR(`/api/analysis/${home}/${away}`, swrAuthedFetcher);
  if (isLoading) return <div className="p-6">Carregando análise...</div>;
  if (error) return <div className="p-6 text-red-400">Erro ao carregar análise.</div>;
  const probs = data?.probs || {};
  const evRows = (data?.evPerBookmaker || []).filter((r:any)=> r.best?.odd).map((r:any)=>({ bookmaker:r.bookmaker, ev:Number(r.best.ev), odd:Number(r.best.odd), selection:r.best.label }));
  const oddsRows = (data?.breakdown || []).map((b:any)=>({ bookmaker:b.bookmaker, homeOdd: b.homeOdd? Number(b.homeOdd): null, drawOdd: b.drawOdd? Number(b.drawOdd): null, awayOdd: b.awayOdd? Number(b.awayOdd): null }));
  return (
    <div className="p-4 md:p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{data.match}</h1>
          <p className="text-gray-400">{new Date(data.kickoff).toLocaleString()} • {data.league}</p>
        </div>
        <Link to="/" className="px-3 py-2 rounded bg-[#2a2a2a]">Voltar</Link>
      </div>

      <section className="grid md:grid-cols-3 gap-4">
        <div className="bg-[#1e1e1e] p-4 rounded border border-[#2a2a2a]">
          <h3 className="font-semibold mb-2">Probabilidades (IA)</h3>
          <ul className="text-sm text-gray-300 space-y-1">
            <li>Casa: <span className="text-blue-400">{(probs.pHome*100).toFixed(1)}%</span></li>
            <li>Empate: <span className="text-blue-400">{(probs.pDraw*100).toFixed(1)}%</span></li>
            <li>Fora: <span className="text-blue-400">{(probs.pAway*100).toFixed(1)}%</span></li>
          </ul>
        </div>
        <div className="bg-[#1e1e1e] p-4 rounded border border-[#2a2a2a] md:col-span-2">
          <h3 className="font-semibold mb-2">EV por Casa (melhor seleção)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-gray-400">
                <tr><th className="py-2 pr-4">Bookmaker</th><th className="py-2 pr-4">Seleção</th><th className="py-2 pr-4">Odd</th><th className="py-2 pr-4">EV</th></tr>
              </thead>
              <tbody>
                {data.evPerBookmaker?.map((row:any,i:number)=>(
                  <tr key={i} className="border-t border-[#2a2a2a]">
                    <td className="py-2 pr-4">{row.bookmaker}</td>
                    <td className="py-2 pr-4">{row.best?.label || '-'}</td>
                    <td className="py-2 pr-4">{row.best?.odd ? Number(row.best.odd).toFixed(2) : '-'}</td>
                    <td className={`py-2 pr-4 ${row.best?.ev>0?'text-emerald-400':'text-red-400'}`}>{row.best?.ev ? (row.best.ev>0?'+':'')+row.best.ev.toFixed(2) : '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="bg-[#1e1e1e] p-4 rounded border border-[#2a2a2a]">
        <h3 className="font-semibold mb-2">EV por Casa (gráfico)</h3>
        <div className="w-full h-64">
          <ResponsiveContainer>
            <LineChart data={evRows}>
              <CartesianGrid stroke="#2a2a2a" />
              <XAxis dataKey="bookmaker" stroke="#aaa" />
              <YAxis stroke="#aaa" />
              <Tooltip contentStyle={{ background: '#1e1e1e', borderColor: '#2a2a2a' }} />
              <Line type="monotone" dataKey="ev" stroke="#00d084" dot />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="bg-[#1e1e1e] p-4 rounded border border-[#2a2a2a]">
        <h3 className="font-semibold mb-2">Odds por Casa</h3>
        <div className="w-full h-72">
          <ResponsiveContainer>
            <BarChart data={oddsRows}>
              <CartesianGrid stroke="#2a2a2a" />
              <XAxis dataKey="bookmaker" stroke="#aaa" />
              <YAxis stroke="#aaa" />
              <Tooltip contentStyle={{ background: '#1e1e1e', borderColor: '#2a2a2a' }} />
              <Legend />
              <Bar dataKey="homeOdd" fill="#4da3ff" name="Casa" />
              <Bar dataKey="drawOdd" fill="#f1c40f" name="Empate" />
              <Bar dataKey="awayOdd" fill="#ff7675" name="Fora" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <LegalFooter />
    </div>
  );
}
