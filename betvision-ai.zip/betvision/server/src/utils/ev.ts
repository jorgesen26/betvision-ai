
export function calcularEV(probReal: number, oddCasa: number) {
  return (probReal * oddCasa) - 1;
}
