
import { Router } from 'express';
import Stripe from 'stripe';
import { env } from '../env.js';
import { firestore } from '../firebaseAdmin.js';
import bodyParser from 'body-parser';

const router = Router();
const stripe = env.STRIPE_SECRET_KEY ? new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' }) : null;

router.post('/create-checkout-session', async (req, res) => {
  try {
    if (!stripe) return res.status(500).json({ error: 'Stripe não configurado' });
    const priceId = env.STRIPE_PRICE_ID_PRO;
    if (!priceId) return res.status(500).json({ error: 'PRICE_ID não configurado' });
    const origin = (req.headers.origin as string) || 'http://localhost:5173';
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${origin}/?success=true`,
      cancel_url: `${origin}/?canceled=true`,
      client_reference_id: (req as any).uid || undefined,
    });
    res.json({ url: session.url });
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

export const stripeWebhookMiddleware = bodyParser.raw({ type: 'application/json' });

router.post('/webhook', stripeWebhookMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(500).json({ error: 'Stripe não configurado' });
    const sig = req.headers['stripe-signature'] as string;
    const secret = env.STRIPE_WEBHOOK_SECRET;
    if (!secret) return res.status(500).json({ error: 'STRIPE_WEBHOOK_SECRET não configurado' });
    const event = stripe.webhooks.constructEvent(req.body, sig, secret);
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const uid = session.client_reference_id;
        const customerId = session.customer as string | undefined;
        let userDocRef = uid ? firestore.collection('users').doc(uid) : null;
        if (!userDocRef && session.customer_details?.email) {
          userDocRef = firestore.collection('users').doc(`email:${session.customer_details.email}`);
        }
        if (userDocRef) {
          await userDocRef.set({ subscription: { plan: 'pro', stripeCustomerId: customerId || null, updatedAt: new Date().toISOString() } }, { merge: true });
        }
        break;
      }
      case 'customer.subscription.deleted':
      case 'invoice.payment_failed': {
        const sub = event.data.object as any; const customerId = sub.customer as string;
        const snap = await firestore.collection('users').where('subscription.stripeCustomerId', '==', customerId).get();
        for (const doc of snap.docs) {
          await doc.ref.set({ subscription: { plan: 'free', updatedAt: new Date().toISOString() } }, { merge: true });
        }
        break;
      }
      default: break;
    }
    res.json({ received: true });
  } catch (e:any) { console.error('Webhook error:', e.message); res.status(400).send(`Webhook Error: ${e.message}`); }
});

export default router;
