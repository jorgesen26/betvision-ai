
import { Router } from 'express';
import { getLiveAndUpcomingFixtures } from '../services/football.js';
import { getOdds } from '../services/odds.js';
import { calcularEV } from '../utils/ev.js';
import { estimateProbabilities } from '../services/model.js';
import { withCache } from '../utils/cache.js';
import { normalizeTeamName, pickBestMatch } from '../utils/teamName.js';

const router = Router();
const cachedFixtures = withCache('fixtures_live_upcoming', getLiveAndUpcomingFixtures);
const cachedOdds = withCache('odds_h2h', getOdds);

router.get('/', async (_req, res) => {
  try {
    const [fixtures, odds] = await Promise.all([cachedFixtures(), cachedOdds()]);
    const oddsIndex = new Map<string, { home?: number; draw?: number; away?: number }>();
    const oddsTeamsSet = new Set<string>();

    for (const ev of odds as any[]) {
      const rawHome = ev.home_team as string | undefined;
      const rawAway = ev.away_team as string | undefined;
      const nHome = normalizeTeamName(rawHome);
      const nAway = normalizeTeamName(rawAway);
      const bm = ev.bookmakers?.[0];
      const market = bm?.markets?.find((m: any) => m.key === 'h2h');
      let homeOdd: number | undefined, drawOdd: number | undefined, awayOdd: number | undefined;
      if (market?.outcomes) {
        for (const o of market.outcomes) {
          const on = normalizeTeamName(o.name);
          if (on && nHome && on.includes(nHome)) homeOdd = o.price;
          else if (on && nAway && on.includes(nAway)) awayOdd = o.price;
          else if (on.includes('draw')) drawOdd = o.price;
        }
      }
      if (nHome && nAway) {
        oddsIndex.set(`${nHome}__${nAway}`, { home: homeOdd, draw: drawOdd, away: awayOdd });
        oddsTeamsSet.add(nHome); oddsTeamsSet.add(nAway);
      }
    }

    const recommendations: any[] = [];
    for (const fx of fixtures as any[]) {
      const homeTeam = fx.teams?.home?.name as string | undefined;
      const awayTeam = fx.teams?.away?.name as string | undefined;
      if (!homeTeam || !awayTeam) continue;
      const nHome = normalizeTeamName(homeTeam);
      const nAway = normalizeTeamName(awayTeam);
      let o = oddsIndex.get(`${nHome}__${nAway}`);
      if (!o) {
        const teamList = Array.from(oddsTeamsSet);
        const bestHome = pickBestMatch(nHome, teamList);
        const bestAway = pickBestMatch(nAway, teamList);
        if (bestHome && bestAway) o = oddsIndex.get(`${bestHome}__${bestAway}`);
      }
      if (!o) continue;
      const features = { homeForm: 0.6, awayForm: 0.5, homeAdvantage: 0.15, oddsAvgHome: o.home, oddsAvgAway: o.away };
      const { pHome, pDraw, pAway } = estimateProbabilities(features);
      const candidates = [
        { label:'Casa', prob:pHome, odd:o.home },
        { label:'Empate', prob:pDraw, odd:o.draw },
        { label:'Fora', prob:pAway, odd:o.away },
      ].filter(c=> c.odd && c.odd>1.01) as any[];
      if (!candidates.length) continue;
      const best = candidates.map(c=> ({...c, ev: calcularEV(c.prob, c.odd)})).sort((a,b)=> b.ev-a.ev)[0];
      if (best && best.ev>0) {
        recommendations.push({ match:`${homeTeam} vs ${awayTeam}`, selection:best.label, prob:best.prob, odd:best.odd, ev:best.ev, kickoff: fx.fixture?.date, league: fx.league?.name });
      }
    }

    recommendations.sort((a,b)=> b.ev-a.ev);
    res.json({ recommendations: recommendations.slice(0,20) });
  } catch (e:any) { console.error(e); res.status(500).json({ error: e.message }); }
});

export default router;
