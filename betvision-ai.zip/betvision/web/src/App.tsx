
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Analysis from './pages/Analysis';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

export default function App(){
  return (
    <div className="dark bg-[#121212] min-h-screen text-white">
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login/>} />
          <Route path="/" element={<Protected><Dashboard/></Protected>} />
          <Route path="/analysis/:home/:away" element={<Protected><Analysis/></Protected>} />
          <Route path="/terms" element={<Terms/>} />
          <Route path="/privacy" element={<Privacy/>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

function Protected({ children }: { children: React.ReactNode }){
  const { user, loading } = useAuth();
  if (loading) return <div className="p-6">Carregando...</div>;
  if (!user) return <Navigate to="/login"/>;
  return <>{children}</>;
}
