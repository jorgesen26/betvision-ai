
import { loginWithGoogle } from '../firebase';
export default function Login(){
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#121212]">
      <div className="bg-[#1e1e1e] p-8 rounded-xl shadow-xl max-w-md w-full">
        <h1 className="text-2xl font-bold mb-4">BetVision AI</h1>
        <p className="text-gray-300 mb-6">Faça login com Google para acessar o painel e as melhores entradas do dia.</p>
        <button onClick={loginWithGoogle} className="w-full py-3 rounded-lg bg-[#007BFF] hover:bg-blue-600 transition font-semibold">Entrar com Google</button>
      </div>
    </div>
  );
}
