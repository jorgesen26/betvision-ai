
import 'dotenv/config';
import { z } from 'zod';

const envSchema = z.object({
  API_FOOTBALL_KEY: z.string().optional(),
  ODDS_API_KEY: z.string().optional(),
  PLAN_FREE_DAILY_LIMIT: z.string().default('5'),
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_PRICE_ID_PRO: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  FIREBASE_PROJECT_ID: z.string().optional(),
  GOOGLE_APPLICATIONS_CREDENTIALS: z.string().optional(),
  MOCK_MODE: z.string().optional(),
});

export const env = envSchema.parse(process.env);
