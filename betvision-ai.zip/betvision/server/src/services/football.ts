
import fetch from 'node-fetch';
import { env } from '../env.js';

export async function getLiveAndUpcomingFixtures() {
  if (env.MOCK_MODE === '1') {
    return [
      { league:{name:'La Liga'}, teams:{home:{name:'Real Madrid'}, away:{name:'Barcelona'}}, fixture:{date:new Date(Date.now()+3600e3).toISOString()} },
      { league:{name:'Premier League'}, teams:{home:{name:'Arsenal'}, away:{name:'Chelsea'}}, fixture:{date:new Date(Date.now()+7200e3).toISOString()} },
    ];
  }
  const url = 'https://v3.football.api-sports.io/fixtures?live=all';
  const res = await fetch(url, { headers: { 'x-apisports-key': env.API_FOOTBALL_KEY as string } });
  if (!res.ok) throw new Error(`API-Football error: ${res.status}`);
  const data = await res.json();
  return data.response;
}
