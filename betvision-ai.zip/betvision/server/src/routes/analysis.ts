
import { Router } from 'express';
import { withCache } from '../utils/cache.js';
import { getLiveAndUpcomingFixtures } from '../services/football.js';
import { getOdds } from '../services/odds.js';
import { normalizeTeamName, pickBestMatch } from '../utils/teamName.js';
import { estimateProbabilities } from '../services/model.js';
import { calcularEV } from '../utils/ev.js';

const router = Router();
const cachedFixtures = withCache('fixtures_live_upcoming', getLiveAndUpcomingFixtures);
const cachedOdds = withCache('odds_h2h', getOdds);

router.get('/:home/:away', async (req, res) => {
  try {
    const homeParam = normalizeTeamName(decodeURIComponent(req.params.home));
    const awayParam = normalizeTeamName(decodeURIComponent(req.params.away));
    const [fixtures, odds] = await Promise.all([cachedFixtures(), cachedOdds()]);

    let targetFixture: any = null;
    for (const fx of fixtures as any[]) {
      const nh = normalizeTeamName(fx.teams?.home?.name);
      const na = normalizeTeamName(fx.teams?.away?.name);
      if (nh === homeParam && na === awayParam) { targetFixture = fx; break; }
    }
    if (!targetFixture) {
      const allTeams = (fixtures as any[]).flatMap(fx=> [normalizeTeamName(fx.teams?.home?.name), normalizeTeamName(fx.teams?.away?.name)]).filter(Boolean) as string[];
      const bestHome = pickBestMatch(homeParam, allTeams);
      const bestAway = pickBestMatch(awayParam, allTeams);
      if (bestHome && bestAway) targetFixture = (fixtures as any[]).find(fx=> normalizeTeamName(fx.teams?.home?.name)===bestHome && normalizeTeamName(fx.teams?.away?.name)===bestAway);
    }
    if (!targetFixture) return res.status(404).json({ error:'Partida não encontrada' });

    const homeName = targetFixture.teams?.home?.name; const awayName = targetFixture.teams?.away?.name;
    const breakdown: any[] = [];
    for (const ev of odds as any[]) {
      const nh = normalizeTeamName(ev.home_team); const na = normalizeTeamName(ev.away_team);
      if ((nh===homeParam && na===awayParam) || (normalizeTeamName(homeName)===nh && normalizeTeamName(awayName)===na)) {
        for (const bk of (ev.bookmakers || [])) {
          const market = bk.markets?.find((m:any)=> m.key==='h2h'); if (!market?.outcomes) continue;
          let homeOdd, drawOdd, awayOdd;
          for (const o of market.outcomes) {
            const on = normalizeTeamName(o.name);
            if (on.includes(normalizeTeamName(homeName))) homeOdd = o.price;
            else if (on.includes(normalizeTeamName(awayName))) awayOdd = o.price;
            else if (on.includes('draw')) drawOdd = o.price;
          }
          breakdown.push({ bookmaker: bk.title || bk.key, homeOdd, drawOdd, awayOdd });
        }
      }
    }
    const avg = (arr:number[])=> arr.length? arr.reduce((a,b)=>a+b,0)/arr.length : undefined;
    const features = {
      homeForm: 0.6, awayForm: 0.5, homeAdvantage: 0.15,
      oddsAvgHome: avg(breakdown.map(b=> b.homeOdd).filter(Boolean) as number[]),
      oddsAvgAway: avg(breakdown.map(b=> b.awayOdd).filter(Boolean) as number[]),
    };
    const probs = estimateProbabilities(features);
    const evPerBookmaker = breakdown.map(b=> {
      const cands = [
        { label:'Casa', prob: probs.pHome, odd: b.homeOdd },
        { label:'Empate', prob: probs.pDraw, odd: b.drawOdd },
        { label:'Fora', prob: probs.pAway, odd: b.awayOdd },
      ].filter(c=> c.odd);
      const best = cands.map(c=> ({...c, ev: calcularEV(c.prob, c.odd!)})).sort((a,b)=> b.ev-a.ev)[0];
      return { bookmaker: b.bookmaker, best };
    });

    res.json({ match:`${homeName} vs ${awayName}`, kickoff: targetFixture.fixture?.date, league: targetFixture.league?.name, probs, breakdown, evPerBookmaker });
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});

export default router;
