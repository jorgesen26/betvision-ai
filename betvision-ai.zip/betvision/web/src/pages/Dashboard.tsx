
import React from 'react';
import useSWR from 'swr';
import { swrAuthedFetcher, authedFetch } from '../lib/fetcher';
import { useAuth } from '../hooks/useAuth';
import { logout } from '../firebase';
import { Link } from 'react-router-dom';
import LegalFooter from '../components/LegalFooter';

export default function Dashboard(){
  const { user } = useAuth();
  const { data: fixtures } = useSWR('/api/matches', swrAuthedFetcher);
  const { data: recs, error } = useSWR('/api/recommendations', swrAuthedFetcher);

  async function handleUpgrade(){
    const res = await authedFetch('/api/billing/create-checkout-session', { method:'POST' });
    const data = await res.json();
    if (data.url) window.location.href = data.url; else alert(data.error || 'Erro ao iniciar checkout.');
  }

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-6xl mx-auto">
      <Header onUpgrade={handleUpgrade} user={user} />

      {error?.status === 429 && (
        <div className="bg-[#2a2a2a] border border-[#3a3a3a] p-4 rounded text-yellow-300">
          Você atingiu o limite diário do plano gratuito. Faça upgrade para o Pro para acesso ilimitado.
        </div>
      )}

      <section>
        <h2 className="text-xl font-semibold mb-3">Jogos em andamento e próximos</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {fixtures?.fixtures?.slice(0,9).map((fx:any, i:number)=>(
            <div key={i} className="bg-[#1e1e1e] rounded-lg p-4 border border-[#2a2a2a]">
              <div className="text-sm text-gray-400">{fx.league?.name}</div>
              <div className="text-lg font-medium mt-1">{fx.teams?.home?.name} vs {fx.teams?.away?.name}</div>
              <div className="text-gray-300 text-sm mt-2">{new Date(fx.fixture?.date).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-3">Melhores Entradas do Dia</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recs?.recommendations?.map((r:any, i:number)=>(
            <div key={i} className="bg-[#1e1e1e] rounded-lg p-4 border border-[#2a2a2a]">
              <h3 className="text-lg font-semibold">{r.match}</h3>
              <p className="text-sm text-gray-300 mt-1">
                Odd: <span className="text-[#FFD700] font-medium">{Number(r.odd).toFixed(2)}</span> | 
                Prob. Real: <span className="text-blue-400 font-medium">{(r.prob*100).toFixed(1)}%</span> | 
                EV: <span className={r.ev>0?'text-emerald-400':'text-red-400'}>{r.ev>0?'+':''}{r.ev.toFixed(2)}</span>
              </p>
              <Link to={`/analysis/${encodeURIComponent(r.match.split(' vs ')[0].toLowerCase().replace(/\s+/g,'-'))}/${encodeURIComponent(r.match.split(' vs ')[1].toLowerCase().replace(/\s+/g,'-'))}`} className="mt-3 inline-block px-3 py-2 rounded-md bg-[#007BFF] hover:bg-blue-600 text-sm">Ver análise detalhada</Link>
            </div>
          ))}
        </div>
      </section>

      <LegalFooter />
    </div>
  );
}

function Header({ onUpgrade, user }: { onUpgrade: () => void; user: any }){
  const [me, setMe] = React.useState<any>(null);
  React.useEffect(()=>{ (async()=>{ try{ const r=await authedFetch('/api/me'); if(r.ok) setMe(await r.json()); }catch{} })(); },[]);
  const isPro = me?.plan === 'pro';
  const photo = user?.photoURL; const name = user?.displayName || user?.email || 'Usuário';
  return (
    <div className="flex items-center justify-between">
      <div>
        <h1 className="text-2xl font-bold">BetVision AI</h1>
        <p className="text-gray-400">Sinalização automática de value bets (EV &gt; 0)</p>
      </div>
      <div className="flex items-center gap-3">
        {!isPro && (
          <button onClick={onUpgrade} className="px-3 py-2 rounded-md bg-[#FFD700] text-black font-semibold hover:brightness-95">Assine Pro</button>
        )}
        {isPro && <span className="px-3 py-2 rounded-md bg-emerald-600 text-white text-sm">Plano Pro ativo</span>}
        <div className="flex items-center gap-2 pl-3 ml-3 border-l border-[#2a2a2a]">
          {photo ? (<img src={photo} alt="avatar" className="w-8 h-8 rounded-full" />) : (
            <div className="w-8 h-8 rounded-full bg-[#2a2a2a] flex items-center justify-center text-sm">{name?.[0]?.toUpperCase()||'U'}</div>
          )}
          <span className="text-sm text-gray-300">{name}</span>
          <button onClick={logout} className="px-2 py-1 rounded bg-[#2a2a2a] hover:bg-[#373737] text-sm">Sair</button>
        </div>
      </div>
    </div>
  );
}
