
import { Request, Response, NextFunction } from 'express';
import { authAdmin, firestore } from '../firebaseAdmin.js';

export interface AuthedRequest extends Request { uid?: string; plan?: 'free'|'pro'; }

export async function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ')? auth.slice(7): null;
  if (!token) return res.status(401).json({ error:'Missing Authorization Bearer token' });
  try {
    const decoded = await authAdmin.verifyIdToken(token);
    req.uid = decoded.uid;
    const userDoc = await firestore.collection('users').doc(decoded.uid).get();
    const plan = (userDoc.exists ? userDoc.data()?.subscription?.plan : 'free') || 'free';
    req.plan = plan === 'pro' ? 'pro' : 'free';
    next();
  } catch {
    return res.status(401).json({ error:'Invalid token' });
  }
}

export function enforceDailyLimit(limitFree: number) {
  return async (req: AuthedRequest, res: Response, next: NextFunction) => {
    const uid = req.uid; const plan = req.plan || 'free';
    if (!uid) return res.status(401).json({ error:'Unauthorized' });
    if (plan === 'pro') return next();
    const today = new Date().toISOString().slice(0,10);
    const ref = firestore.collection('usage').doc(uid);
    const snap = await ref.get();
    let data: any = snap.exists ? snap.data() : null;
    if (!data || data.date !== today) data = { date: today, count: 0 };
    if (data.count >= limitFree) return res.status(429).json({ error:'Limite diário atingido. Faça upgrade para o plano Pro.' });
    await ref.set({ date: today, count: data.count + 1 }, { merge: true });
    next();
  };
}
