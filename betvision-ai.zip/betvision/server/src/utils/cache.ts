
import LRU from 'lru-cache';

export const cache = new LRU<string, any>({ max: 500, ttl: 60 * 1000 });

export function withCache<T>(key: string, fn: () => Promise<T>) {
  return async () => {
    const hit = cache.get(key);
    if (hit) return hit as T;
    const data = await fn();
    cache.set(key, data);
    return data;
  };
}
