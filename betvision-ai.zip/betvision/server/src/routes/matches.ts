
import { Router } from 'express';
import { withCache } from '../utils/cache.js';
import { getLiveAndUpcomingFixtures } from '../services/football.js';
const router = Router();
const cachedFixtures = withCache('fixtures_live_upcoming', getLiveAndUpcomingFixtures);

router.get('/', async (_req, res) => {
  try {
    const fixtures = await cachedFixtures();
    res.json({ fixtures });
  } catch (e:any) { res.status(500).json({ error: e.message }); }
});
export default router;
