
export default function LegalFooter(){
  return (
    <footer className="mt-10 pt-6 pb-10 text-xs text-gray-400 border-t border-[#2a2a2a]">
      <div className="max-w-5xl mx-auto px-4">
        <p>Aviso: Apostas envolvem risco e podem causar perdas financeiras. Aposte de forma responsável. Este aplicativo não garante ganhos e não é uma casa de apostas. Uso restrito a maiores de 18 anos, sujeito à legislação local. As probabilidades e recomendações são informativas e podem mudar sem aviso.</p>
        <div className="mt-2">
          <a href="/terms" className="underline hover:text-white">Termos de Uso</a>
          <span className="mx-2">•</span>
          <a href="/privacy" className="underline hover:text-white">Política de Privacidade</a>
        </div>
      </div>
    </footer>
  );
}
