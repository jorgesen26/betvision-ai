
export default function Privacy(){
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Política de Privacidade</h1>
      <div className="prose prose-invert max-w-none text-gray-200">
        <p>Última atualização: 01/11/2025</p>
        <p>Esta Política de Privacidade descreve como o BetVision AI coleta, usa e protege dados pessoais...</p>
      </div>
    </div>
  );
}
