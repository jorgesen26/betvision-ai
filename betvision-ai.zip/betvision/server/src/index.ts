
import express from 'express';
import cors from 'cors';
import matchesRouter from './routes/matches.js';
import oddsRouter from './routes/odds.js';
import recsRouter from './routes/recommendations.js';
import analysisRouter from './routes/analysis.js';
import billingRouter, { stripeWebhookMiddleware } from './routes/billing.js';
import { requireAuth, enforceDailyLimit } from './middleware/auth.js';
import { env } from './env.js';

const app = express();
app.use(cors());

// Webhook Stripe (raw)
app.post('/api/billing/webhook', stripeWebhookMiddleware, (req, res, next) => { next(); }, billingRouter);

app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/api/matches', requireAuth, matchesRouter);
app.use('/api/odds', requireAuth, oddsRouter);
app.use('/api/recommendations', requireAuth, enforceDailyLimit(Number(env.PLAN_FREE_DAILY_LIMIT)), recsRouter);
app.use('/api/analysis', requireAuth, analysisRouter);
app.use('/api/billing', requireAuth, billingRouter);

app.get('/api/me', requireAuth, (req, res) => { res.json({ uid: (req as any).uid, plan: (req as any).plan || 'free' }); });

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`API running on :${port}`));
